it('greets', () => {
  cy.visit('./cypress/integration/examples/app.html')
  cy.get('#name').type('Cypress{enter}')
  cy.contains('#answer', 'Hello, Cypress')
})