describe('My first program' , ()=> {
it('Visit Calc Page',() =>{
cy.visit('https://www.online-calculator.com//html5/online-calculator/index.php?v=10')
 document.getElementById('canvas').then(function(e){(new KeyboardEvent("keypress",{key: "5"}))})
		//.then(
	//new KeyboardEvent("keypress",{key: "5"}))
})
})	