package com.online.calc;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

public class MainMethodOnlineCalc {

	public static void main(String[] args) throws Exception, IOException {

		WebDriver driver = null;
		WebElement canvas = null;

		// System.setProperty("webdriver.chrome.driver", "D:\\NPN\\Selenium
		// WebDriver with Java\\ChromeDriver\\latest\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", ".\\src\\com\\online\\calc\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		driver = new ChromeDriver(options);
		driver.get("https://www.online-calculator.com/html5/online-calculator/index.php?v=10");
		Actions builder = new Actions(driver);

		XSSFWorkbook wb = new XSSFWorkbook(
				new FileInputStream("D:\\AppiumProject\\Appium\\src\\com\\online\\calc\\TestCases.xlsx"));
		XSSFSheet sheet = wb.getSheetAt(0);
		int activeRows = sheet.getPhysicalNumberOfRows();

		XSSFRow currRow;

		for (int i = 1; i < activeRows; i++) {
			currRow = sheet.getRow(i);
			canvas = driver.findElement(By.id("canvas"));
			MainMethodOnlineCalc obj = new MainMethodOnlineCalc();
			String value = currRow.getCell(4).getRichStringCellValue().toString().trim();
			Action send2ToCanvas = builder.sendKeys(canvas, value).build();
			send2ToCanvas.perform();
			//Thread.sleep(1000);
			File calcImage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			int Width = canvas.getSize().getWidth();
			int Height = canvas.getSize().getHeight();

			Point point = canvas.getLocation();
			int x = point.getX();
			int y = point.getY();
			String actual = "";
			String expected = "";

			BufferedImage img = ImageIO.read(calcImage);
			BufferedImage dest = img.getSubimage(x, y, Width, Height);
			ImageIO.write(dest, "png", calcImage);
			actual = "D:\\Calc\\actual_" + currRow.getCell(0) + ".png";

			FileUtils.copyFile(calcImage, new File(actual));
			BufferedImage actualImage = ImageIO.read(new File(actual));

			expected = "D:\\Calc\\expected_" + currRow.getCell(0) + ".png";
			BufferedImage expectedImage = ImageIO.read(new File(expected));

			ImageDiffer imgDiff = new ImageDiffer();
			ImageDiff diff = imgDiff.makeDiff(actualImage, expectedImage);
			int a = diff.getDiffSize();
			if (a == 0) {
				System.out.println( currRow.getCell(0) + " PASS : calculated value matches expected value");
			} else {
				System.out.println( currRow.getCell(0) + " FAIL : calculated value does matche expected value");
			}

		}
		driver.quit();
	}
}
